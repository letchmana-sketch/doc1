# Teaching & Learning Platform
Minimal Next.js + Firebase starter.